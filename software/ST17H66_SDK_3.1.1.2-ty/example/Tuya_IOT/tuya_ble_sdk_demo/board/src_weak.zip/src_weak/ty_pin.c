#include "ty_pin.h"




/*********************************************************************
 * LOCAL CONSTANT
 */

/*********************************************************************
 * LOCAL STRUCT
 */

/*********************************************************************
 * LOCAL VARIABLE
 */

/*********************************************************************
 * VARIABLE
 */

/*********************************************************************
 * LOCAL FUNCTION
 */




/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_pin_init(uint8_t pin, ty_pin_mode_t mode)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_pin_set(uint8_t pin, ty_pin_level_t level)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_pin_get(uint8_t pin, ty_pin_level_t* p_level)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_pin_control(uint8_t pin, uint8_t cmd, void* arg)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_pin_uninit(uint8_t pin, ty_pin_mode_t mode)
{
    return 0;
}







