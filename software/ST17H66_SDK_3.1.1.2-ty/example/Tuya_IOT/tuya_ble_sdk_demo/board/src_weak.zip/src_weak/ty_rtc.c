#include "ty_rtc.h"




/*********************************************************************
 * LOCAL CONSTANT
 */

/*********************************************************************
 * LOCAL STRUCT
 */

/*********************************************************************
 * LOCAL VARIABLE
 */

/*********************************************************************
 * VARIABLE
 */

/*********************************************************************
 * LOCAL FUNCTION
 */




/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_rtc_init(void)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_rtc_set_time(uint32_t app_timestamp)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_rtc_get_time(uint32_t* p_timestamp)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_rtc_get_local_time(uint32_t* p_timestamp)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_rtc_get_old_time(uint32_t old_local_timestamp, uint32_t* p_timestamp)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_rtc_control(uint8_t cmd, void* arg)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_rtc_uninit(void)
{
    return 0;
}







