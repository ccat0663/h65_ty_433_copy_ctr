#include "ty_system.h"




/*********************************************************************
 * LOCAL CONSTANT
 */
            
/*********************************************************************
 * LOCAL STRUCT
 */

/*********************************************************************
 * LOCAL VARIABLE
 */

/*********************************************************************
 * VARIABLE
 */

/*********************************************************************
 * LOCAL FUNCTION
 */




/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_init(uint8_t location)
{
    switch(location)
    {
        case 0: {
        } break;
        
        case 1: {
        } break;
        
        case 2: {
        } break;
        
        default: {
        } break;
    }
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_mainloop(void)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_reset(void)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_enter_critical(void)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_exit_critical(void)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_wdt_init(void)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_wdt_feed(void)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_log_init(void)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_log_hexdump(const char *name, uint8_t width, uint8_t *buf, uint16_t size)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_delay_ms(uint32_t ms)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_system_delay_us(uint32_t us)
{
    return 0;
}






