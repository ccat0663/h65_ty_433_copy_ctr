#include "ty_timer.h"




/*********************************************************************
 * LOCAL CONSTANT
 */
            
/*********************************************************************
 * LOCAL STRUCT
 */

/*********************************************************************
 * LOCAL VARIABLE
 */

/*********************************************************************
 * VARIABLE
 */

/*********************************************************************
 * LOCAL FUNCTION
 */




/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_timer_create(void** p_timer_id, uint32_t ms, ty_timer_mode_t mode, ty_timer_handler_t handler)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_timer_delete(void* timer_id)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_timer_start(void* timer_id)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_timer_stop(void* timer_id)
{
    return 0;
}

/*********************************************************
FN: 
*/
__TUYA_BLE_WEAK uint32_t ty_timer_restart(void* timer_id, uint32_t ms)
{
    return 0;
}






